import { Injectable } from '@angular/core';
import { Http } from '@angular/http';

@Injectable()
export class DataService {
  users;

  constructor(private _http: Http) {
    this.users = [];
   }

  addUser(user, cb){
    this._http.post('./adduser', user).subscribe((res) => {
      this.users.push(res.json());
      cb();
    })
  }

  getAll(cb){
    this._http.get('./getall').subscribe((res) => {
      this.users = res.json();
     cb();
    })
  }


}
