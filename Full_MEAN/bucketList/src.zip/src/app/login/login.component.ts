import { Component, OnInit } from '@angular/core';
import { DataService } from './../data.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  user;
  users;

  constructor(private _dataService: DataService, private_router: Router) {
    this.users = [];
    this.user = {name: ""}
    this.users = this._dataService.getAll(() => {
      this.users = this._dataService.users
    });
  }

  addUser(){
    this._dataService.addUser(this.user, function(res){
      this.user = { name: ""};
      this._router.navigate(["/"]);
      this._dataService.getAll(() => {
        this.users = this._dataService.users; 
        
      })
      
      
    })
  }
    
  ngOnInit() {
  }

}
