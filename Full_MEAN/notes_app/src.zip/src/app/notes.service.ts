import { Injectable } from '@angular/core';

@Injectable()
export class NotesService {
  notes = []
   
    constructor() { }

    createNote(note){
      console.log(note);
      this.notes.push(note);
    }

    retrieveNotes({Note:note}){

    }
}
