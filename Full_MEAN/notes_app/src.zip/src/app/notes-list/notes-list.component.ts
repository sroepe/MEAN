import { Component, OnInit } from '@angular/core';
import { NotesService } from '../notes.service';

@Component({
  selector: 'app-notes-list',
  templateUrl: './notes-list.component.html',
  styleUrls: ['./notes-list.component.css']
})
export class NotesListComponent implements OnInit {

  constructor(private _dataService: NotesService) { }

  retrieveNotes(notes: {note: String, noted_on: Date}){


  }
  ngOnInit() {
  }

}
