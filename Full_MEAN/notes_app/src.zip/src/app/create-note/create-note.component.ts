import { Component, OnInit , EventEmitter, Output } from '@angular/core';
import { NotesService } from '../notes.service';
import { Note } from '../../../../server/models/notes';

@Component({
  selector: 'app-create-note',
  templateUrl: './create-note.component.html',
  styleUrls: ['./create-note.component.css']
})
export class CreateNoteComponent implements OnInit {
  notes;
  // notes = [
  //   {note: String, noted_on: Date}
  // ]

  @Output() createNoteEvent = new EventEmitter();

  

  constructor(private _dataService: NotesService) { }

  ngOnInit() {

  }

  onSubmit(formData) {
    console.log(formData);
    this.notes = [{note: String, noted_on: Date}];
    this.createNoteEvent.emit(this.notes);
    console.log(this.notes);
  }
}
