import { Component, OnInit } from '@angular/core';
import { MainService } from './../main.service';
import { Router } from '@angular/router';
import { ActivatedRoute } from "@angular/router";

@Component({
  selector: 'app-add-question',
  templateUrl: './add-question.component.html',
  styleUrls: ['./add-question.component.css']
})
export class AddQuestionComponent implements OnInit {
  question;

  constructor(private _mainService:MainService, private _router:Router) { 
    this.question = {question: "", correct: "", fake1: "", fake2: ""};
  }

    ngOnInit() {
  }

  submitQuestion(){
    this._mainService.submitQuestion(this.question, (res) => {
      this._router.navigate(['home'])
    })
  }
}
