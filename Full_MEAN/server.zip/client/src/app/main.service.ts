import { Injectable } from '@angular/core';
import { Http } from '@angular/http';

@Injectable()
export class MainService {

  constructor(private _http: Http) { 

  }

  login(user, cb){
    this._http.post('/login', user).subscribe((res) => {
      cb(res.json());
    })
  }

  checkSession(cb){
    this._http.get('/check').subscribe((res) => {
      cb(res.json());
    })
  }

  newGame(cb){
    this._http.get('/newgame').subscribe((res) => {
      cb(res.json())
    })
  }

  cancel(cb){
    this._http.get('/cancel').subscribe((res) => {
      cb(res.json());
    })
  }

  addQuestion(cb){
    this._http.get('/addquestion').subscribe((res) => {
      cb(res.json())
    })
  }

  submitQuestion(question, cb){
    this._http.post('/submitquestion', question).subscribe((res) => {
      cb(res.json());
    })
  }

}
