import { Component, OnInit } from '@angular/core';
import { MainService } from './../main.service';
import { Router } from '@angular/router';
import { ActivatedRoute } from "@angular/router";

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  loggedUser;
  user;

  constructor(private _mainService:MainService, private _router: Router, private _route: ActivatedRoute) {
    this.loggedUser = user;
    console.log(this.user)
  }

  ngOnInit() {
    // this.checkSession();
  }

  // checkSession(){
  //   this._mainService.checkSession((user) => {
  //     if(!user) {
  //       this._router.navigate([""]);
  //     }
  //     else{
  //       this.loggedUser = user
  //     }
  //   })
  // }

  newGame(){
    this._router.navigate(["lets_play"])
  }

  addQuestion(){
    this._router.navigate(["new_question"])
  }


}
