import { Component, OnInit } from '@angular/core';
import { MainService } from './../main.service';
import { Router } from '@angular/router';
import { ActivatedRoute } from "@angular/router";

@Component({
  selector: 'app-questions',
  templateUrl: './questions.component.html',
  styleUrls: ['./questions.component.css']
})
export class QuestionsComponent implements OnInit {
  loggedUser;
  questions = [];
  question;
  
    constructor(private _mainService:MainService, private _router:Router) {
      this.loggedUser = {name: ""};
      this.question = {question: "", correct: "", fake1: "", fake2: ""};
    }
  ngOnInit() {
    this.randomQ();
  }  

  randomQ (){
    for (let y = 0; y < this.questions.length; y++){
      const randomNum = Math.floor(Math.random() * this.questions.length) + 1;
      console.log(this.questions[y])
    }
  }

  cancelTest(){
    this._router.navigate(["home"])
  }

  addQuestion(){
    this._router.navigate(["new_question"])
  }

 


}
