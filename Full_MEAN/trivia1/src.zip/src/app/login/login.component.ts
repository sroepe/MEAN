import { Component, OnInit } from '@angular/core';
import { MainService } from './../main.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  user;

  constructor(private _mainService: MainService, private _router: Router) {
    this.user = {name: ""};
  }

  login(){
    this._mainService.login(this.user, (res) => {
      this._router.navigate(['home'])
      
    })
  }

  ngOnInit() {
    // this.checkSession();
  }

  // checkSession(){
  //   this._mainService.checkSession((user) => {
  //     if(!this.user) {
  //       this._router.navigate([""]);
  //     }
  //     else{
  //       this._router.navigate(['home'])
  //     }
  //   })
  // }

}
