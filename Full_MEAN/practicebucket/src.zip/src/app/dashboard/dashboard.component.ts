import { Component, OnInit } from '@angular/core';
import { DataService } from "./../data.service";
import { Router } from "@angular/router";
import { ActivatedRoute } from "@angular/router";

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  currentUser;
  allUsers;
  list;
  allList;
  oneUser;

  constructor(private _dataService:DataService, private _router: Router, private _route: ActivatedRoute) {
    this.currentUser = {name: ""};
    this.allUsers = [{}];
    this.getAll();
    this.list = {creator: "", title: "", description: "", other_users:[], created_on: "", done:""};
    this.allList = [{}];
    this.getList();
    this.oneUser = { name: ""};
    this.markDone();
    // this.getUserList();
  }

  ngOnInit() {
    this.checkSession();
  }

  getAll(){
    this._dataService.getAll((data) =>{
      this.allUsers = data.users;
    })
  }

  checkSession(){
    this._dataService.checkSession((data) => {
      if(!data.user) {
        this._router.navigate([""]);
      }
      else{
        this.currentUser = data.user
      }
    }) 
  }
  addList(){
    this._dataService.addList(this.list, (res) => {
      this._router.navigate(["dashboard"])
    })
  }

  getList(){
    this._dataService.getList((data) => {
      this.allList = data.lists;
     
    })
  }
  getUserList(){
    // this._dataService.getUserList((data) => {
    //   this.oneUser = data.users[];
    //   this._router.navigate(["users", this.oneUser])
    // })

    // this._dataService.getUserList
    this._router.navigate[("user/:id")]
    this._route.paramMap.subscribe((params) => {
      console.log(params.get('id'));
    })

  }

  markDone(){
    this._dataService.markDone(this.list, (res) => {
      this._router.navigate(["dashboard"]);
    })
    console.log("markDone in dbcomp.ts is working")
  }

}
