import { Injectable } from '@angular/core';
import { Http } from '@angular/http';

@Injectable()
export class DataService {

  constructor(private _http: Http) { 
    
  }

  login(user, cb){
    this._http.post('/login', user).subscribe((res) => {
      cb(res.json());
    })
  }

  checkSession(cb){
    this._http.get('/check').subscribe((res) => {
      cb(res.json());
    })
  }

  addList(list, cb){
    this._http.post('/addlist', list).subscribe((res) => {
      cb(res.json())
    })
  }

  getAll(cb){
    this._http.get('/allusers').subscribe((res) => {
      cb(res.json());
    })
  }

  getList(cb){
    this._http.get('/allitems').subscribe((res) => {
      cb(res.json());
    })
  }

  markDone(list, cb){
    this._http.post('/markdone', list).subscribe((res) => {
      cb(res.json());
    })
  }
  getUserList(cb){
    this._http.get('/user/:id').subscribe((res) => {
      cb(res.json());
    })
  }
}
