import { Component, OnInit } from '@angular/core';
import { DataService } from "./../data.service";
import { Router } from "@angular/router";
import { ActivatedRoute } from "@angular/router";

@Component({
  selector: 'app-userview',
  templateUrl: './userview.component.html',
  styleUrls: ['./userview.component.css']
})
export class UserviewComponent implements OnInit {
  allUsers

  constructor(private _dataService:DataService, private _router: Router) {
    this.getAll();
  }

  ngOnInit() {
  }

  getAll(){
    this._dataService.getAll((data) =>{
      this.allUsers = data.users;
    })
  }   
  

}
