import { Component } from '@angular/core';
import { Button } from 'selenium-webdriver';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  buttons = [true, true, true, true, true, true, true, true, true, true];

  flipSwitch(idx){
    this.buttons[idx] = !this.buttons[idx];
    
  
  }
}

