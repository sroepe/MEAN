import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-quoteslist',
  templateUrl: './quoteslist.component.html',
  styleUrls: ['./quoteslist.component.css']
})
export class QuoteslistComponent implements OnInit {
  @Input() quotes = {};
  constructor() { }

  ngOnInit() {
  }

}
