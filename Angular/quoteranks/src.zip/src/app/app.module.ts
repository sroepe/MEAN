import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';

import { AppRoutingModule } from './app-routing.module';

import { AppComponent } from './app.component';
import { AddquoteComponent } from './addquote/addquote.component';
import { QuoteslistComponent } from './quoteslist/quoteslist.component';


@NgModule({
  declarations: [
    AppComponent,
    AddquoteComponent,
    QuoteslistComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
