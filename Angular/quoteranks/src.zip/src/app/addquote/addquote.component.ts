import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';


@Component({
  selector: 'app-addquote',
  templateUrl: './addquote.component.html',
  styleUrls: ['./addquote.component.css']
})

export class AddquoteComponent implements OnInit {
  @Input() quotes;
  @Output() createQuoteEvent = new EventEmitter();

  newQuote = {body: "", author: "", rating: 0};

  constructor() { }

  ngOnInit() {
  }

  onSubmit(formData) {
    console.log(formData);
    this.newQuote = {body: "", author: "", rating: 0};
    this.createQuoteEvent.emit(this.newQuote);
  
    console.log(this.newQuote);
  }

}
