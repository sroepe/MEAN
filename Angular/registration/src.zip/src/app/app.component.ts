import { Component } from '@angular/core';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  user = {
    firstName: "",
    lastName: "",
    email: "",
    pw: "",
    confirmpw: "",
    address: "",
    unit: "",
    city: "",
    state: "",
    lucky: "",

  };
  users = [];
  onSubmit(){
    this.users.push(this.user);
    this.user = {
      firstName: "",
      lastName: "",
      email: "",
      pw: "",
      confirmpw: "",
      address: "",
      unit: "",
      city: "",
      state: "",
      lucky: "",
    }
    
    console.log(this.users)
  }
}
