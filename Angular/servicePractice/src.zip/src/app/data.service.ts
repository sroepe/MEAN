import { Injectable } from '@angular/core';

@Injectable()
export class DataService {
  numbersOne: number[] = [];
  numbersTwo: number[] = [];
  result: number = 0;

    constructor() { }

    retrieveNumbersOne(): number[] {
      return this.numbersOne;
    }
    retrieveNumbersTwo(): number[] {
      return this.numbersTwo;
    }

    retrieveResult(): number {
      return this.result;
    }

    addNumberOne(num: number) {
      num = Math.floor(Math.random() * 9);
      this.numbersOne.push(num);
    }
    addNumberTwo(num: number) {
      num = Math.floor(Math.random() * 9);
      this.numbersTwo.push(num);
    }

    sumOneTwo() {
      var oneSum = 0;
      for(var i = 0; i < this.numbersOne.length; i++){
        oneSum += this.numbersOne[i];
      }
      
      var twoSum = 0;
      for(var j = 0; j < this.numbersTwo.length; j++){
        twoSum += this.numbersTwo[j];
      }
      this.result = oneSum - twoSum;
      console.log(oneSum);
      console.log(twoSum);
      console.log(this.result);
      return this.result;
    }

}
