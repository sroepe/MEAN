import { Component, OnInit } from '@angular/core';

import { DataService } from '../data.service';

@Component({
  selector: 'app-beta',
  templateUrl: './beta.component.html',
  styleUrls: ['./beta.component.css']
})
export class BetaComponent implements OnInit {
  numbersTwo: number[] = [];

  constructor(private _dataService: DataService) { }

  ngOnInit() {
    this.numbersTwo = this._dataService.retrieveNumbersTwo();
  }
  pushTwo() {
    this._dataService.addNumberTwo(Math.floor(Math.random() * 9));
  }
}
