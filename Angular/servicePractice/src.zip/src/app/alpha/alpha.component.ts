import { Component, OnInit } from '@angular/core';

import { DataService } from '../data.service';

@Component({
  selector: 'app-alpha',
  templateUrl: './alpha.component.html',
  styleUrls: ['./alpha.component.css']
})
export class AlphaComponent implements OnInit {
  numbersOne: number[] = [];

  constructor(private _dataService: DataService) { }

  ngOnInit() {
    this.numbersOne = this._dataService.retrieveNumbersOne();
  }

  pushOne() {
    this._dataService.addNumberOne(Math.floor(Math.random() * 9));
  }

}
