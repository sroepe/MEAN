import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-washdc',
  templateUrl: './washdc.component.html',
  styleUrls: ['./washdc.component.css']
})
export class WashdcComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
